<?php

namespace App\Models\Shop;

use Illuminate\Database\Eloquent\Model;

//商品相册模型
class ProductGallery extends Model
{
    //
    protected $guarded = [];
}

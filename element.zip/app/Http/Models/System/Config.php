<?php

namespace App\Models\System;

use Illuminate\Database\Eloquent\Model;

class Config extends Model
{
    public $timestamps = false;
    protected $guarded = [];
}
